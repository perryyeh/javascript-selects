﻿Name:		叶子多级联动下拉菜单(DynamicOptionList on Javascript by Yeh)
Author:		Perry Yeh(叶子)
Version:	1.0.4.rc
Release:	2008-09-24
Copy(c):	FreeSoftWare(自由软件)
Contact:	http://www.yeeh.org/
License:	GPL(GNU LESSER GENERAL PUBLIC LICENSE)
Descript:	多级别多数量联动下拉菜单，本程序在(os:win2003)ie6 ie7 opera9 firefox3 chrome0.2 safari3.1下测试通过

---------------------------------------------------------------------------
注意：本程序的保存格式均为UTF-8，如果使用时候发现乱码，请打开另存正确格式。
---------------------------------------------------------------------------

ReadMe:
本程序遵循GPL协议。
保留版权信息情况下您可以免费使用本程序，若有修改请抄送原作者一份。
调用示范参见演示文件。

File:
readme.txt            说明文档
license.txt           许可方式
changelog.txt         更新历史

data_asp/             数据生成文件夹
data_asp/china.mdb    动易cms省市数据库（修改版）
data_asp/china.asp    省市生成页面(执行完毕请查看html源码 直接浏览器复制可能会多空格符而导致最终数据不匹配)
data_asp/job.mdb      人才分类数据库
data_asp/job.asp      人才分类生成页面(执行完毕请查看html源码 直接浏览器复制可能会多空格符而导致最终数据不匹配)

build/		      压缩版文件夹(正式使用推荐压缩版本)
build/selects.js      联动下拉类文件
build/data_job.js     两级联动人才数据
build/data_china.js   三级联动省市区数据

demo/		      演示文件夹(未压缩版本,便于查看源码)
demo/index.html	      演示文件
demo/firefox.html     firefox event测试文件
demo/selects.js	      联动菜单js文件
demo/data_job.js      两级联动人才数据
demo/data_china.js    三级联动省市区数据
demo/data_demo.js     四级联动&多子类测试数据

Thanks:
星╄Astral：某些提醒=_=!~
^Talent^：测试以及推广
王好奇：某些hack
tinymce：某些dom操作方法
动易cms：省市数据

