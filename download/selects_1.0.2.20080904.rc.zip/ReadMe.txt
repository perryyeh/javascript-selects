﻿名称:		多级联动下拉菜单
Name:		DynamicOptionList on Javascript
Release:	1.0.2.20080904.rc
Author:		Perry Yeh(叶子)
Revision:	2008-09-04 12:50
Licenses:	GPL(The GNU General Public License)
Copy(c):	FreeSoftWare(自由软件)
Descript:	多级别多数量联动下拉菜单，本程序在(win2003平台)ie6 ie7 opera9 firefox3 chrome0.2 safari3.1下测试通过
Contact:	http://www.yeeh.org

ReadMe:
本程序遵循GPL协议。
保留版权信息情况下您可以免费使用本程序，若有修改请抄送原作者一份。
调用示范参见演示文件。

File:
data_china.js	中国省级县市数据（不完整）
demo.html		调用示范
selects.js		联动菜单js文件
ReadMe.txt		说明文档

Thanks:
星╄Astral
^Talent^
tinymce

History:
-------------------------------------------------------
1.02：
a.代码格式化
-------------------------------------------------------
1.01：
a.多级别联动
b.多子类联动