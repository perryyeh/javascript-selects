var selects = {
	//绑定数据
	bind : function(o,d) {
		o['_data'] = d;
		for (var i=0; i<d.length; i++) {
			if (!d[i].index && !d[i].value && !d[i].text) {
				for (var j=0; j<d[i].data.length; j++) {
					this._addOption(o,d[i].data[j][0],d[i].data[j][1]);
				}
			}
		}
	},
	//确定父子关系
	parent : function(op,oc){
		change = function(){
			selects._clearOption(oc);
			var d = oc['_data'];
			var idx = op.selectedIndex;
			var v = op.options[idx].value;
			var t = op.options[idx].text;
			for (var i=0; i<d.length; i++) {
				if ((d[i].value == v) || (d[i].text == t) || (d[i].index == idx)) {
					for (var j=0; j<d[i].data.length; j++) {
						selects._addOption(oc,d[i].data[j][0],d[i].data[j][1])
					}
				}
			}
			selects._fireEvent(oc,'change');
		};
		this._addEvent(op,'change',change);
	},
	//设置默认值
	selected : function(o,d) {
		if (!!d.index) {
			if (!!o.options[d.index]) {
				o.options[d.index].selected = true;
			};
		} else if (!!d.value) {
			o.value = d.value;
		} else if (!!d.text) {
			for (var i=0; i<o.options.length; i++) {
				if (o.options[i].text == d.text) {
					o.options[i].selected = true;
				};
			}
		}
		this._fireEvent(o,'change');
	},
	//添加
	_addOption : function(o,v,t) {
		o.options.add(new Option(t,v));
	},
	//删除索引选项
	_removeOption : function(o,i) {
		if (o.options.remove) {
			o.options.remove(i);
		} else {
			o.options[i] = null;
		}
	},
	//清空
	_clearOption : function(o) {
		o.options.length = 0 ;
	},
	//强制触发
	_fireEvent : function(o,n) {
		if (o.fireEvent) {
			o.fireEvent('on' + n);
		} else {
			var evt = document.createEvent('HTMLEvents');
			evt.initEvent(n,true,true);
			o.dispatchEvent(evt);
		}
	},
	//添加事件
	_addEvent : function(o, n, f) {
		if (o.attachEvent) {
			o.attachEvent('on' + n, f);
		} else if (o.addEventListener) {
			o.addEventListener(n, f, false);
		} else {
			o['on' + n] = f;
		}
	},
	//删除事件
	_removeEvent : function(o, n, f) {
		if (o.detachEvent) {
			o.detachEvent('on' + n, f);
		} else if (o.removeEventListener) {
			o.removeEventListener(n, f, false);
		} else {
			o['on' + n] = null;
		}
	},
	//版权
	version : {
		author : 'Perry Yeh',
		contact : 'http://www.yeeh.org',
		major : '1',
		minor : '0.2',
		release : '2008.09.04',
		revision : 'rc',
		get : function(){
			with(this){
				return major + '.' + minor + '.' + release + '.' + revision;
			};
		}
	}
};